<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $connection = mysqli_connect("localhost", "root", "", "prs");
    if (!$connection) {
        echo "Database connection error.";
        exit;
    }

    $name = $_POST["name"];
    $description = $_POST["description"];
    $price = $_POST["price"];
    $status = $_POST["status"];

    if (isset($_FILES["image"]) && $_FILES["image"]["error"] === UPLOAD_ERR_OK) {
        $target_dir = "uploads/";
        $image_name = $_FILES["image"]["name"];
        $image_tmp = $_FILES["image"]["tmp_name"];
        $image_type = $_FILES["image"]["type"];
        $image_size = $_FILES["image"]["size"];

        $allowed_extensions = array('jpg', 'jpeg', 'png', 'gif');
        $file_extension = strtolower(pathinfo($image_name, PATHINFO_EXTENSION));
        if (!in_array($file_extension, $allowed_extensions)) {
            echo "Error: Invalid file type. Only JPG, JPEG, PNG, and GIF images are allowed.";
            exit;
        }

        $max_file_size = 5242880; // 5MB
        if ($image_size > $max_file_size) {
            echo "Error: The file size exceeds the maximum allowed limit (5MB).";
            exit;
        }

        $new_filename = uniqid('', true) . '.' . $file_extension;
        $target_file = $target_dir . $new_filename;

        if (!move_uploaded_file($image_tmp, $target_file)) {
            echo "Error: Failed to upload the image.";
            exit;
        }
     } //else {
    //     echo "Error: Failed to upload the image.";
    //     exit;
    // }

    $query = "INSERT INTO items (name, description, price, status, image)
              VALUES ('$name', '$description', '$price', '$status', '$image')";
    $result = mysqli_query($connection, $query);

    if ($result) {
        header("Location: admin_dashboard.php?add_item=success");
        exit;
    } else {
        echo "Error adding item: " . mysqli_error($connection);
        exit;
    }

    mysqli_close($connection);
}
?>
