<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $connection = mysqli_connect("localhost", "root", "", "prs");
    if (!$connection) {
        echo "Database connection error.";
        exit;
    }

    $item_id = $_POST["item_id"];
    $quantity = $_POST["quantity"];
    $address = $_POST["address"];

    $query = "SELECT * FROM items WHERE id = $item_id AND status = 'Active'";
    $result = mysqli_query($connection, $query);
    if (mysqli_num_rows($result) === 0) {
        echo "Error: Invalid item selected or item is inactive.";
        exit;
    }

    $query = "INSERT INTO orders (item_id, quantity, address) VALUES ('$item_id', '$quantity', '$address')";
    $result = mysqli_query($connection, $query);

    if ($result) {
        // Fetch the item name to display in the success message
        $item_query = "SELECT name FROM items WHERE id = $item_id";
        $item_result = mysqli_query($connection, $item_query);
        $item_row = mysqli_fetch_assoc($item_result);
        $item_name = $item_row['name'];
        echo "Order placed successfully! You ordered $quantity units of $item_name.";
    } else {
        echo "Error placing order: " . mysqli_error($connection);
    }

    mysqli_close($connection);
}
?>
