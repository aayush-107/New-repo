<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
<!-- Section 3: Delete Item -->
<div class="section" id="section3">
    <h2>Delete Item</h2>
    <form action="delete_item.php" method="post">
        <label for="item_id">Select Item to Delete:</label>
        <select id="item_id" name="item_id" required>
            <option value="">Select an item</option>
            <!-- PHP code to fetch items data and populate the dropdown -->
            <?php
            $connection = mysqli_connect("localhost", "root", "", "prs");
            if (!$connection) {
                echo "Database connection error.";
            } else {
                $query = "SELECT * FROM items"; // Retrieve all items
                $result = mysqli_query($connection, $query);

                while ($row = mysqli_fetch_assoc($result)) {
                    echo '<option value="' . $row['id'] . '">' . $row['name'] . '</option>';
                }

                mysqli_close($connection);
            }
            ?>
        </select>
        <input type="submit" name="delete_item" value="Delete Item">
    </form>
</div>
</body>
</html>
