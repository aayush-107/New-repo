<?php
$host = "localhost"; // Example: localhost
$username = "root";
$password = "";
$db_name = "prs";

$conn = mysqli_connect($host, $username, $password, $db_name);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
function get_items()
{
    global $conn;
    $query = "SELECT * FROM refinery_data";
    $result = mysqli_query($conn, $query);
    $refineries = mysqli_fetch_all($result, MYSQLI_ASSOC);
    return $refineries;
}

?>
