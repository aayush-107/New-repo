<?php
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["delete_item"])) {
    // Check if the form is submitted and the "delete_item" parameter is set

    // Connect to the database
    $connection = mysqli_connect("localhost", "root", "", "prs");
    if (!$connection) {
        echo "Database connection error.";
        exit;
    }

    // Get the item ID from the form
    $item_id = $_POST["item_id"];

    // Check if the item exists in the database
    $query = "SELECT * FROM items WHERE id = $item_id";
    $result = mysqli_query($connection, $query);
    if (mysqli_num_rows($result) === 0) {
        echo "Error: Item not found.";
        exit;
    }

    // Delete the item from the database
    $query = "DELETE FROM items WHERE id = $item_id";
    $result = mysqli_query($connection, $query);

    // Check if the deletion was successful
    if ($result) {
        echo "Item deleted successfully!";
    } else {
        echo "Error deleting item: " . mysqli_error($connection);
    }

    // Close the database connection
    mysqli_close($connection);
}
?>
