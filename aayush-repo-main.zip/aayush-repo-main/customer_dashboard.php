<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <nav class="navbar">
        <div class="container">
            <a class="navbar-brand" href="#">User Dashboard</a>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="#section1">View Items</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#section2">Place Order</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <h1>Welcome to the cuatomers Dashboard</h1>

        <div class="section" id="section1">
            <h2>View Items</h2>
            <div class="item-list">
                <?php
                $connection = mysqli_connect("localhost", "root", "", "prs");
                if (!$connection) {
                    echo "Database connection error.";
                } else {
                    $query = "SELECT * FROM items WHERE status = 'Active'"; // Retrieve only active items
                    $result = mysqli_query($connection, $query);

                    while ($row = mysqli_fetch_assoc($result)) {
                        echo '<div class="item">';
                        echo '<img src="uploads/' . $row['image'] . '" alt="' . $row['name'] . '">';
                        echo '<h3>' . $row['name'] . '</h3>';
                        echo '<p>' . $row['description'] . '</p>';
                        echo '<p>Price: $' . $row['price'] . '</p>';
                        echo '</div>';
                    }

                    mysqli_close($connection);
                }
                ?>
            </div>
        </div>

        <div class="section" id="section2">
            <h2>Place Order</h2>
            <form action="submit_order.php" method="post">
                <label for="item_id">Select Item:</label>
                <select id="item_id" name="item_id" required>
                    <option value="">Select an item</option>
                    <?php
                    $connection = mysqli_connect("localhost", "root", "", "prs");
                    if (!$connection) {
                        echo "Database connection error.";
                    } else {
                        $query = "SELECT * FROM items WHERE status = 'Active'"; // Retrieve only active items
                        $result = mysqli_query($connection, $query);

                        while ($row = mysqli_fetch_assoc($result)) {
                            echo '<option value="' . $row['id'] . '">' . $row['name'] . '</option>';
                        }

                        mysqli_close($connection);
                    }
                    ?>
                </select>
                <label for="quantity">Quantity:</label>
                <input type="number" id="quantity" name="quantity" min="1" value="1" required>
                <label for="address">address:</label>
                <input type="text" id="address"name="address" min="1" value="10" required>
                <input type="submit" value="Place Order">



                </address>
            </form>
        </div>
    </div>

</body>

</html>
