<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Connect to the database
    $con = mysqli_connect("localhost", "root", "", "prs");

    // Check if the connection was successful
    if (!$con) {
        echo "error";
    } else {
        // Get the form data
        $name = $_POST["name"];
        $email = $_POST["email"];
        $address = $_POST["address"];

        // Perform SQL query to update the profile
        $query = "UPDATE customers SET name = '$name', email = '$email', address = '$address' WHERE id = 1"; // Replace 'customers' with your customer table name and 1 with the customer ID
        $result = mysqli_query($con, $query);

        // Check if the update was successful
        if ($result) {
            // Redirect back to the customer dashboard with a success message
            header("Location: customer_dashboard.php?update=success");
            exit;
        } else {
            // Display an error message
            echo "Error updating profile: " . mysqli_error($con);
        }

        // Close the database connection
        mysqli_close($con);
    }
}
?>
