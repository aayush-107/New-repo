<!-- Section 4: View Customers -->
<div class="section" id="section4">
    <h2>View Customers</h2>
    <table class="customer-table">
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>address</th>
            <!-- Add more columns here as per your customer table structure -->
        </tr>
        <!-- PHP code to fetch customer data and display in the table -->
        <?php
        $connection = mysqli_connect("localhost", "root", "", "prs");
        if (!$connection) {
            echo "Database connection error.";
        } else {
            $query = "SELECT * FROM customers";
            $result = mysqli_query($connection, $query);

            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row['id'] . "</td>";
                echo "<td>" . $row['name'] . "</td>";
                echo "<td>" . $row['email'] . "</td>";
                echo "<td>" . $row['address'] . "</td>";
                // Add more columns here as per your customer table structure
                echo "</tr>";
            }

            mysqli_close($connection);
        }
        ?>
    </table>
</div>
