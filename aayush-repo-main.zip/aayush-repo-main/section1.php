<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
<!-- Section 1 -->

    <div class="section" id="section1">
   <h2>Section 1: Item List</h2>
   <table class="item-table">
       <tr>
           <th>ID</th>
           <th>Name</th>
           <th>Description</th>
           <th>Price</th>
           <th>Status</th>
           <th>Image</th>
       </tr>
       <!-- PHP code to fetch items data and display in the table -->
       <?php
       $connection = mysqli_connect("localhost", "root", "", "prs");
       if (!$connection) {
           echo "Database connection error.";
       } else {
           $query = "SELECT * FROM items"; // Replace 'items' with your item table name
           $result = mysqli_query($connection, $query);

           while ($row = mysqli_fetch_assoc($result)) {
               echo "<tr>";
               echo "<td>" . $row['id'] . "</td>";
               echo "<td>" . $row['name'] . "</td>";
               echo "<td>" . $row['description'] . "</td>";
               echo "<td>$" . $row['price'] . "</td>";
               echo "<td>" . $row['status'] . "</td>";
               echo "<td><img src='uploads/" . $row['image'] . "' alt='Item Image' height='100'></td>";
               echo "</tr>";
           }

           mysqli_close($connection);
       }
       ?>
   </table>
</div>
</div>\
</body>

</html>
