<?php
    $name = $_REQUEST['name'];
    echo "<h1>I welcome you Mr. $name as a customer.</h1>"
?>