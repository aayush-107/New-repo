<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
<!-- Section 2 -->
<div class="section" id="section2">
    <h2>Section 2: Add Item</h2>
    <form action="add_item.php" method="post">
        <label for="name">Item Name:</label>
        <input type="text" id="name" name="name" required><br>
        <label for="description">Item Description:</label>
        <textarea id="description" name="description" required></textarea><br>
        <label for="price">Item Price:</label>
        <input type="number" step="0.01" id="price" name="price" required><br>
        <label for="status">Item Status:</label>
        <select id="status" name="status" required>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
        </select><br>
        <label for="image">Item Image:</label>
        <input type="file" id="image" name="image" accept="image/*" required><br>
        <input type="submit" value="Add Item">
    </form>
</div>
</div>

</body>

</html>
