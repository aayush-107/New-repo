<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <nav class="navbar">
        <div class="container">
            <a class="navbar-brand" href="#">Dashboard</a>
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="section1.php">Item List</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="section2.php">Add Item</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="section3.php">Delete Item</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="section4.php">View Customers</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container">
        <h1>Welcome to the ADMIN Dashboard</h1>





</body>

</html>
